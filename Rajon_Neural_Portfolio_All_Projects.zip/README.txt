RAJON / NEURAL — AI Automation Portfolio

Included projects:
- BrightCare Clinic AI Voice Receptionist
- HealthCare Plus Appointment Automation
- AI Customer Support Agent
- Order Management Agent

Preview:
1. Extract this ZIP.
2. Open index.html in a browser.
3. The assets folder contains the project workflow screenshots.

Free publishing:
Upload the extracted files to a GitHub repository, then enable GitHub Pages in Settings > Pages.

Static website: no API key or paid hosting required.
